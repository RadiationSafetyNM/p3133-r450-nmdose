g++ -DUNIX -Dunix -DEXE -std=c++11 -I../dgate/dicomlib -I../dgate/lua_5.1.5 -o servertask -Wno-multichar total.cxx -llua5.1
