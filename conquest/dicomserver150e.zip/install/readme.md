** Web based installer **

This folder contains batch files to build/start dgate (linux) or copy/start dgate.exe (windows) that act as a control manager to install/build conquest dicom server using a web interface. It main use is to install under Linux.

Missing features: control SeLinux; create deamon.
