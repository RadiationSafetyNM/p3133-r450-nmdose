<?php 
include "dgate.php";
