lua -i service.lua 1 2 3 subfunction compiledgate_all
