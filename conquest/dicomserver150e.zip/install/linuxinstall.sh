sudo apt install lua5.1
lua5.1 installer.lua
